Lexora Foundation avatar source assets

Eight supplied, newly cropped Foundation avatar PNGs, copied unchanged for the Foundation collection.
The web collection manifest maps them to foundation-01 through foundation-08.
